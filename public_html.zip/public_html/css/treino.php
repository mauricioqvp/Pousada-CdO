﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sem título</title>
<link href="treino.css" rel="stylesheet" type="text/css">
</head>

<body>
ola mundo php
</body>
</html>